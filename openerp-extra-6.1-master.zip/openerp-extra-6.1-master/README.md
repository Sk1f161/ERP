openerp-extra-6.1
=================

OpenERP Extra Addons 6.1